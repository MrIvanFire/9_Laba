package com.example.fourteen;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        TextView textView = findViewById(R.id.changeTxt2);
        SpannableString spannable = new SpannableString("Повседневная практика показывает, что перспективное планирование позволяет выполнить важные задания по разработке существующих финансовых и административных условий");


        spannable.setSpan (
                new StyleSpan(Typeface.BOLD),
                 0, 5,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                );



        spannable.setSpan (
                new StyleSpan (Typeface.ITALIC),
                7,  14,
                Spanned. SPAN_EXCLUSIVE_EXCLUSIVE

        );



        spannable.setSpan (
                new ForegroundColorSpan(Color.RED),
                27, 37,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE

        );
        spannable.setSpan (
                new UnderlineSpan(),
                39, 50,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE

        );
        spannable.setSpan (
                new StrikethroughSpan(),
                52, 64,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE

                );
        textView.setText(spannable);
    }
}