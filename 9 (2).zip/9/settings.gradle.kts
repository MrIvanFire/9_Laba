pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "9 Лабараторная"
include(":first")
include(":second")
include(":third")
include(":four")
include(":five")
include(":six2")
include(":seven2")
include(":eight")
include(":nine")
include(":ten")
include(":eleven")
include(":twelve")
include(":thirteen")
include(":fourteen")
include(":fifteen")
