package com.example.six2;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.changeTxt);

        TextView textView3 = findViewById(R.id.changeTxt2);

        textView.setTextColor(getResources().getColor(R.color.newColorSuperMegaCool));
        textView.setBackgroundColor(getResources().getColor(R.color.newColorSuperMega));

        textView3.setTextColor(ContextCompat.getColor(this, R.color.newColorSuperMega));
        textView3.setBackgroundColor (ContextCompat.getColor( this, R.color.newColorSuperMegaCool));
        }
    }
