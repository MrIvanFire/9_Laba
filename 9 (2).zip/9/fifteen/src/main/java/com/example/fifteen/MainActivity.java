package com.example.fifteen;

import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        TextView textView51 = findViewById(R.id.changeTxt1);
        TextView textView52 = findViewById(R.id.changeTxt2);

        String html = "<b>Bold</b> and <i>italic</i>";
        Spanned text = Html.fromHtml(html, Html.FROM_HTML_MODE_COMPACT);
        textView51.setText(text);
        Log.e("HTML",String.valueOf(text));
        String htmlWithLink = "Посетите <a href='https://www.oat.ru/'>Наш сайт</a> для подробностей";
        Spanned linkText = Html.fromHtml(htmlWithLink,Html.FROM_HTML_MODE_LEGACY);
        textView52.setText(linkText);
        textView52.setMovementMethod(LinkMovementMethod.getInstance());
    }
}